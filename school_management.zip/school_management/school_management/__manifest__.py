# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

{
	'name': 'School Management',
	'version': '10.0.',
	'author': '''Swarna''',
	'category': 'School Management',
	'Summary': 'School Management',
	'depends': ['hr', 'account', 'account_accountant','report'],
	'data': [
			'security/school_security.xml',
			'security/ir.model.access.csv',
			'views/student_view.xml',
			'views/school_view.xml',
			'views/teacher_view.xml',
			'views/parent_view.xml',
			'views/template_view.xml',
			'data/student_sequence.xml',
			],
	'demo': [],
	'installable': True,
	'application': True
}
