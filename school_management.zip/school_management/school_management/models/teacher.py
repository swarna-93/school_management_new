# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api


class SchoolTeacher(models.Model):
	''' Here Defining a Teacher information '''
	_name = 'school.teacher'
	_inherits = {'hr.employee': 'employee_id'}
	_description = 'Teacher Information'

	employee_id = fields.Many2one('hr.employee', 'Employee ID',ondelete="cascade",delegate=True, required=True)
	subject_id = fields.Many2many('subject.subject', 'subject_teacher_rel','teacher_id', 'subject_id','Course-Subjects')
	school_id = fields.Many2one('res.company', "Campus", store=True)
	department_id = fields.Many2one('hr.department', 'Department')
	job_id = fields.Many2one('hr.job', 'Job Title')
	phone_number = fields.Char("Phone Number")
	teacher_code = fields.Char("Teachers ID")

	@api.model
	def create(self, vals):
		vals['company_id']=vals['school_id']
		teacher_id = super(SchoolTeacher, self).create(vals)
		user_id = self.env['res.users'].create({'name': teacher_id.name,
					'login': teacher_id.work_email,
					'email': teacher_id.work_email,
					'company_id':teacher_id.school_id.id,
					'company_ids': [(6,0,teacher_id.school_id.ids)],
					})
		teacher_grp,base_grp = self.env.ref('school_management.group_school_teacher'),self.env.ref('base.group_user')
		teacher_group_ids = [teacher_grp.id, base_grp.id]
		user_id.write({'groups_id': [(6, 0, teacher_group_ids)]})
		teacher_id.employee_id.write({'user_id': user_id.id})
		return teacher_id


