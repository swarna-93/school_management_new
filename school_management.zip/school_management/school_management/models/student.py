# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

import time
# import re
from datetime import date, datetime
from odoo import models, fields, api
from odoo.tools.translate import _
from odoo.modules import get_module_resource
# from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from odoo.exceptions import except_orm
from odoo.exceptions import ValidationError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT
# from dateutil.relativedelta import relativedelta
from .import school

# from lxml import etree
# added import statement in try-except because when server runs on
# windows operating system issue arise because this library is not in Windows.
try:
	from odoo.tools import image_colorize, image_resize_image_big
except:
	image_colorize = False
	image_resize_image_big = False


class SchoolStudents(models.Model):
	_name = 'school.students'
	_inherits = {'res.users': 'user_id'}
	_description = 'Student Information'

	@api.depends('date_of_birth')
	def _compute_student_age(self):
		'''Method to calculate student age'''
		current_dt = datetime.today()
		for rec in self:
			if rec.date_of_birth:
				start = datetime.strptime(rec.date_of_birth,
										DEFAULT_SERVER_DATE_FORMAT)
				age_calc = ((current_dt - start).days / 365)
				# Age should be greater than 0
				if age_calc > 0.0:
					rec.age = age_calc

	def _compute_invoice(self):
		for std in self:
			inv_ids = self.env['account.invoice'].search([('partner_id','=',std.user_id.partner_id.id)])
			pending_inv_ids = self.env['account.invoice'].search([('partner_id','=',std.user_id.partner_id.id),('state','in',['draft','open'])])
			print 11111,inv_ids,pending_inv_ids
			std.invoice_ids =  [(6,0,inv_ids.ids)]
			std.invoice_count = len(inv_ids)
			std.due_payment = True if len(pending_inv_ids.ids) >= 1 else False
			print std.invoice_ids,std.invoice_count,std.due_payment

	@api.multi
	def action_view_invoices(self):
		'''
		This function returns an action that display invoice records..
		'''
		action = self.env.ref('account.action_invoice_tree1')
		result = action.read()[0]

		#override the context to get rid of the default filtering on picking type
		result['context'] = {}
		inv_ids = self.env['account.invoice'].search([('partner_id','=',self.user_id.partner_id.id)]).ids
		#choose the view_mode accordingly
		result['domain'] = "[('id','in',[" + ','.join(map(str, inv_ids)) + "])]"
		print result['domain']
		if len(inv_ids) == 1:
			res = self.env.ref('account.invoice_form', False)
			result['views'] = [(res and res.id or False, 'form')]
			result['res_id'] = inv_ids and inv_ids[0] or False
		return result

	@api.model
	def create(self, vals):
		'''Method to create user when student is created'''
		if vals.get('student_code', _('New')) == _('New'):
			std_id = self.env['ir.sequence'].next_by_code('student.code') or _('New')
			vals['student_code'],vals['login'],vals['password'] = std_id,std_id,std_id
			print std_id,vals['student_code'],vals['login'],vals['password']
		if vals.get('company_id', False):
			company_vals = {'company_ids': [(4, vals.get('company_id'))],'company_id': vals.get('company_id')}
			vals.update(company_vals)
		res = super(SchoolStudents, self).create(vals)
		emp_grp,student_grp = self.env.ref('base.group_user'),self.env.ref('school_management.group_school_student')
		group_list = [student_grp.id, emp_grp.id]
		res.user_id.write({'groups_id': [(6, 0, group_list)]})
		return res


	user_id = fields.Many2one('res.users', 'User ID', ondelete="cascade",required=True, delegate=True)
	fee_amount = fields.Float('Student Fees Amount')
	student_code = fields.Char('Student ID')
	contact_phone1 = fields.Char('Phone no.',)
	contact_mobile1 = fields.Char('Mobile no',)
	admission_date = fields.Date('Admission Date', default=date.today())
	roll_no = fields.Integer('Roll No.', readonly=True)
	photo = fields.Binary('Photo')
	year = fields.Many2one('academic.year', 'Academic Year', readonly=True)
	gender = fields.Selection([('male', 'Male'), ('female', 'Female')],'Gender')
	date_of_birth = fields.Date('DOB', required=True)
	mother_tongue = fields.Many2one('mother.toungue', "Mother Tongue")
	age = fields.Integer(compute='_compute_student_age', string='Age',readonly=True)
	maritual_status = fields.Selection([('unmarried', 'Unmarried'),('married', 'Married')],'Marital Status')
	blood_group = fields.Char('Blood Group')
	school_id = fields.Many2one('res.company', 'School',)
	division_id = fields.Many2one('standard.division', 'Division')
	medium_id = fields.Many2one('standard.medium', 'Medium')
	standard_id = fields.Many2one('school.standard', 'Class')
	parent_id = fields.Many2many('school.parent', 'students_parents_rel','student_id','students_parent_id', 'Parent(s)')
	active = fields.Boolean(default=True)
	due_payment = fields.Boolean("Fee Due",default=True,compute ='_compute_invoice')
	invoice_count = fields.Integer("Invoice Count",compute ='_compute_invoice')
	invoice_ids = fields.Many2many('account.invoice', 'student_account_rel','student_id','invoice_id', 'Invoices',compute ='_compute_invoice')
