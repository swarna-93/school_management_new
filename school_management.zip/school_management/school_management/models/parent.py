# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api


class ParentRelation(models.Model):
	_name = "parent.relation"
	_description = "Parent and child relation information"

	name = fields.Char("Relation name", required=True)


class SchoolParent(models.Model):
	_name = 'school.parent'
	_description = 'Parent Information'

	name = fields.Char("Name")
	relation_id = fields.Many2one('parent.relation', "Relation with Child")
	student_id = fields.Many2many('school.students', 'students_parents_rel','students_parent_id', 'student_id','Children')
	street = fields.Char("Street")
	street2 = fields.Char("Street2")
	zip = fields.Char("Zip")
	city = fields.Char("City")
	state_id = fields.Many2one("res.country.state", string='State', ondelete='restrict')
	country_id = fields.Many2one('res.country', string='Country', ondelete='restrict')
	email = fields.Char("Email")
	phone = fields.Char("Phone")
	fax = fields.Char("Fax")
	mobile = fields.Char("Mobile")
	comment = fields.Text("Notes")
	active = fields.Boolean("Is Active")
