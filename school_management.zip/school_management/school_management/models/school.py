# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

# import time
import re
import calendar
from datetime import datetime
from odoo import models, fields, api
from odoo.tools.translate import _
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, \
	DEFAULT_SERVER_DATETIME_FORMAT
from odoo.exceptions import except_orm
from odoo.exceptions import ValidationError
from dateutil.relativedelta import relativedelta

class AcademicYear(models.Model):
	''' Defines an academic year '''
	_name = "academic.year"
	_description = "Academeic Year "
	_order = "name"

	name = fields.Char('Name', required=True, help='Name of academic year')
	code = fields.Char('Code', required=True, help='Code of academic year')
	date_start = fields.Date('Start Date', required=True,
							help='Starting date of academic year')
	date_stop = fields.Date('End Date', required=True,
							help='Ending of academic team')
	grade_id = fields.Many2one('grade.master', "Grade")
	description = fields.Text('Description')


class StandardMedium(models.Model):
	_name = "standard.medium"
	_description = "Standard Medium"
	_order = "name"

	name = fields.Char('Name', required=True)
	code = fields.Char('Code', required=True)
	description = fields.Text('Description')


class StandardDivision(models.Model):
	_name = "standard.division"
	_description = "Standard Division"
	_order = "name"

	name = fields.Char('Name', required=True)
	code = fields.Char('Code', required=True)
	description = fields.Text('Description')


class StandardStandard(models.Model):
	_name = 'standard.standard'
	_description = 'Standard Information'
	_order = "name"

	name = fields.Char('Name', required=True)
	code = fields.Char('Code', required=True)
	description = fields.Text('Description')

class SchoolStandard(models.Model):
	_name = 'school.standard'
	_description = 'School Standards'
	_rec_name = "standard_id"

	@api.depends('standard_id', 'school_id', 'division_id', 'medium_id')
	def _compute_student(self):
		'''Compute student of done state'''
		student_obj = self.env['school.students']
		for rec in self:
			domain = [('standard_id', '=', rec.id),
					('school_id', '=', rec.school_id.id),
					('division_id', '=', rec.division_id.id),
					('medium_id', '=', rec.medium_id.id)
					]
			rec.student_ids = student_obj.search(domain)

	@api.onchange('standard_id', 'division_id')
	def onchange_combine(self):
		self.name = str(self.standard_id.name) + '-' + str(self.division_id.name)

	@api.depends('subject_ids')
	def _compute_subject(self):
		'''Method to compute subjects'''
		for rec in self:
			rec.total_no_subjects = len(rec.subject_ids)

	@api.depends('student_ids')
	def _compute_total_student(self):
		for rec in self:
			rec.total_students = len(rec.student_ids)

	@api.multi
	def name_get(self):
		'''Method to display standard and division'''
		return [(rec.id, rec.standard_id.name + '[' + rec.division_id.name +']') for rec in self]

	school_id = fields.Many2one('res.company', 'School', required=True)
	standard_id = fields.Many2one('standard.standard', 'Standard',
								required=True)
	division_id = fields.Many2one('standard.division', 'Division',
								required=True)
	medium_id = fields.Many2one('standard.medium', 'Medium', required=True)
	subject_ids = fields.Many2many('subject.subject', 'subject_standards_rel',
								'subject_id', 'standard_id', 'Subject')
	user_id = fields.Many2one('school.teacher', 'Class Teacher')
	student_ids = fields.One2many('school.students', 'standard_id','Student In Class',compute='_compute_student', store=True)
	color = fields.Integer('Color Index')
	total_no_subjects = fields.Integer('Total No of Subject',compute="_compute_subject")
	name = fields.Char('Name')
	total_students = fields.Integer("Total Students",compute="_compute_total_student",store=True)


class SubjectSubject(models.Model):
	'''Defining a subject '''
	_name = "subject.subject"
	_description = "Subjects"

	name = fields.Char('Name', required=True)
	code = fields.Char('Code', required=True)

class MotherTongue(models.Model):
	_name = 'mother.toungue'
	_description = "Mother Toungue"

	name = fields.Char("Mother Tongue")

class GradeMaster(models.Model):
	_name = 'grade.master'

	name = fields.Char('Grade', required=True)
	grade_ids = fields.One2many('grade.lines', 'grade_id', 'Grade Name')


class GradeLine(models.Model):
	_name = 'grade.lines'
	_rec_name = 'grade'

	from_mark = fields.Integer('From Marks', required=True,
							help='The grade will starts from this marks.')
	to_mark = fields.Integer('To Marks', required=True,
							help='The grade will ends to this marks.')
	grade = fields.Char('Grade', required=True, help="Grade")
	sequence = fields.Integer('Sequence', help="Sequence order of the grade.")
	fail = fields.Boolean('Fail', help='If fail field is set to True,\
								it will allow you to set the grade as fail.')
	grade_id = fields.Many2one("grade.master", 'Grade')
	name = fields.Char('Name')


