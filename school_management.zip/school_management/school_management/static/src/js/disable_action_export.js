odoo.define("school_management.disable_action_export", function(require) {
"use strict";

	var core = require("web.core");
	var Sidebar = require("web.Sidebar");
	var _t = core._t;
	var Model = require("web.DataModel");
	var session = require("web.session");

	Sidebar.include({
		add_items: function(section_code, items) {
			var self = this;
			var _super = this._super;
			var models = this.__parentedParent.model
			console.log("llllll",models);
			var model_list=['school.students']
			if (session.is_superuser) {
				console.log("111111",models);
				_super.apply(this, arguments);
			}
			else{
				var model_res_users = new Model("res.users");
				model_res_users.call("has_group", ["school_management.group_school_administration"]).done(function(can_export) {
					console.log("222222222",models,can_export);
					if (!can_export) {
						var export_label = _t("Export");
						var new_items = items;
						if (model_list.indexOf(models) !== -1)
						{
							// imports.hide();
							if (section_code === "other") {
								new_items = [];
								for (var i = 0; i < items.length; i++) {
									if (items[i]["label"] !== export_label) {
										new_items.push(items[i]);
									}
								}
						}
					}
						if (new_items.length > 0) {
							_super.call(self, section_code, new_items);
						}
					} else {
						_super.call(self, section_code, items);
					}
				});
			}
		}
	});
});
